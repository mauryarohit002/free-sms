<?php
	

	/**
	* 
	*/
	class Rom extends CI_Controller
	{
		public function __construct(){	
			parent::__construct();	
			$this->load->model('rom_model');	
		}

		function index()
		{
			$this->load->view("index");	
		}
		
		function about_us(){
			$this->load->view("about-us");
		}
		
		function contact_us(){
			$this->load->view('contact-us');
		}
		
		function login(){
			$this->load->view('login');
		}
		
		function register_action(){
			   // print_r($_POST);
			 $name=$this->input->post('log_name');
			 $phone=$this->input->post('log_mobile');
			 $email=$this->input->post('log_email');
			 $pass=$this->input->post('log_pass');
			

			 $this->form_validation->set_rules('log_name','Username','trim|required');
			 $this->form_validation->set_rules('log_mobile','Phone','trim|required|exact_length[10]');
			 $this->form_validation->set_rules('log_email','Email','trim|required|valid_email|is_unique[login.email]');
			 $this->form_validation->set_rules('log_pass','Password','trim|required|min_length[4]|max_length[15]');
			 $this->form_validation->set_rules('log_cpass','Password Confirmation','trim|required|matches[log_pass]');


			 if(!$this->form_validation->run()){
			 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));
			 }
			 else{
					$res=$this->rom_model->register_action(array('name'=>$name,'phone'=>$phone,'email'=>$email,'pass'=>$pass));		 	
					if($res>0){
						echo json_encode(array("status"=>'success','desc'=>'register successfully'));
					}
			 }
			 
			 
		}
		
	}

?>