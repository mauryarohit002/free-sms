<?php
	

	/**
	* 
	*/
	class Rom extends CI_Controller
	{
		public function __construct(){	
			parent::__construct();	
			$this->load->model('rom_model');	
		}

		function index()
		{
			$this->load->view("index");	
		}
		
		function about_us(){
			$this->load->view("about-us");
		}
		
		function contact_us(){
			$this->load->view('contact-us');
		}
		
		function login(){
			$this->load->view('login');
		}
		
		function register_action(){
			   // print_r($_POST);
			 $name=$this->input->post('log_name');
			 $phone=$this->input->post('log_mobile');
			 $email=$this->input->post('log_email');
			 $pass=$this->input->post('log_pass');
			

			 $this->form_validation->set_rules('log_name','Username','trim|required');
			 $this->form_validation->set_rules('log_mobile','Phone','trim|required|exact_length[10]');
			 $this->form_validation->set_rules('log_email','Email','trim|required|valid_email|is_unique[login.email]');
			 $this->form_validation->set_rules('log_pass','Password','trim|required|min_length[4]|max_length[15]');
			 $this->form_validation->set_rules('log_cpass','Password Confirmation','trim|required|matches[log_pass]');


			 if(!$this->form_validation->run()){
			 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));
			 }
			 else{	
			 		$data=array('name'=>$name,'phone'=>$phone,'email'=>$email,'pass'=>$pass);
					$res=$this->rom_model->insert_indb('login',$data);		 	
					if($res>0){
						echo json_encode(array("status"=>'success','desc'=>'register successfully.'));
					}
			 }
			 
			 
		}

		function login_action(){
			// print_r($_POST);
			$email=$this->input->post('log_email');
			$pass=$this->input->post('log_pass');
			//$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->form_validation->set_rules('log_email','email','trim|required|valid_email');
			$this->form_validation->set_rules('log_pass','Password','trim|required|min_length[4]|max_length[15]');
			if(!$this->form_validation->run()){
				echo json_encode(array('status'=>'error','desc'=>validation_errors()));
			}
			else{
				  $str=$this->rom_model->login_action(array('email'=>$email,'pass'=>$pass));
				  // print_r($str);
				  if($str>0){
				  		// $this->session->sess_expiration = '10';

				  		$this->session->set_userdata('email',$email);
				  		
				  			echo json_encode(array('status'=>'success','desc'=>'successfully login.'));
				  			
				  }
				  else{
				  	 	echo json_encode(array('status'=>'error','desc'=>'please enter valid email and password.'));	
				  }

			}
		}

		function logout(){
			$this->session->unset_userdata('email');
			$this->session->sess_destroy();
			redirect(base_url('index.php/rom/index'));
		}

		function change_pass(){
			if(!$this->session->userdata('email')){
			redirect(base_url('index.php/rom/logout'));

			}
			$this->load->view('change_password');
		}
		
		function change_password_action(){
			if(!$this->session->userdata('email')){
				redirect(base_url('index.php/rom/logout'));
			}

			$curr_pass=$this->input->post('log_cpass');
			$new_pass=$this->input->post('log_npass');
			$newc_pass=$this->input->post('log_cnpass');

			$this->form_validation->set_rules('log_cpass','Current Password','trim|required');
			$this->form_validation->set_rules('log_npass','new password','trim|required|min_length[4]|max_length[12]|differs[log_cpass]');
			$this->form_validation->set_rules('log_cnpass','confirm new password','trim|required|min_length[4]|max_length[12]|differs[log_cpass]|matches[log_npass]');
			if(!$this->form_validation->run()){
				echo json_encode(array('status'=>'error','desc'=>validation_errors()));	
			}
			else{

				$data=array('cpass'=>$curr_pass,'pass'=>$new_pass,'email'=>$_SESSION['email']);
				
				$val=$this->rom_model->change_password_action($data);
				if($val>0){
					echo json_encode(array('status'=>'success','desc'=>'Password update successfully.'));	
				}
				else{
					echo json_encode(array('status'=>'error','desc'=>"please enter valid current password."));
				}
			}
		}

		function library(){
			if(!$this->session->userdata('email')){
				redirect(base_url('index.php/rom/logout'));
			}
			$data['library']=$this->rom_model->get_data_fromdb('library');
			$data['group']=$this->rom_model->get_data_fromdb('group');
			$this->load->view('library',$data);

		}

		function add_library(){
			// print_r($_POST);
			if(!$this->session->userdata('email')){
				redirect(base_url('index.php/rom/logout'));
			}
			$this->form_validation->set_rules('ca_name','library name','trim|required');
			if(!$this->form_validation->run()){
				echo json_encode(array('status'=>'error','desc'=>validation_errors()));	
			}
			else{
				$res=$this->rom_model->insert_indb('library',$_POST);
				if($res>0){
				echo json_encode(array('status'=>'success','desc'=>"add library successfully"));	

				}
				else{
				echo json_encode(array('status'=>'error','desc'=>"invalid library name"));	
				}
			}

		}

		function add_group(){
			// print_r($_POST);
			if(!$this->session->userdata('email')){
				redirect(base_url('index.php/rom/logout'));
			}
			$this->form_validation->set_rules('gr_name','group name','trim|required');
			if(!$this->form_validation->run()){
				echo json_encode(array('status'=>'error','desc'=>validation_errors()));	
			}
			else{
				$res=$this->rom_model->insert_indb('group',$_POST);
				if($res>0){
				echo json_encode(array('status'=>'success','desc'=>"add group successfully"));	

				}
				else{
				echo json_encode(array('status'=>'error','desc'=>"invalid group name"));	
				}
			}

		}

		function create_message(){
			$data['library']=$this->rom_model->get_data_fromdb('library');
			$this->load->view('create-message',$data);
		}

		function add_message(){
			// print_r($_POST);
			if(!$this->session->userdata('email')){
				redirect(base_url('index.php/rom/logout'));
			}
			$this->form_validation->set_rules('sms_caid','category','trim|required|numeric');
			$this->form_validation->set_rules('sms_msg','message','trim|required|alpha_numeric_spaces');
			if(!$this->form_validation->run()){
				echo json_encode(array('status'=>'error','desc'=>validation_errors()));	

			}
			else{
				$res=$this->rom_model->insert_indb('message',$_POST);
				// print_r($res);
				if($res>0){
				echo json_encode(array('status'=>'success','desc'=>'Message Added.'));	

				}
				else{
				echo json_encode(array('status'=>'error','desc'=>'Invalid Message.'));	

				}
			}

		}

		function add_contact(){
			$data['contact']=$this->rom_model->get_data_fromdb('contact');
			$data['group']=$this->rom_model->get_data_fromdb('group');
			$this->load->view('add-contact',$data);
		}

		function add_contactdb(){
			if(!$this->session->userdata('email')){
				redirect(base_url('index.php/rom/logout'));
			}

			$this->form_validation->set_rules('c_grid','group','trim|required|numeric');
			$this->form_validation->set_rules('c_name','name','trim|required|alpha');
			$this->form_validation->set_rules('c_number','mobile number','trim|required|numeric|exact_length[10]');
			if(!$this->form_validation->run()){
				echo json_encode(array('status'=>'error','desc'=>validation_errors()));	

			}
			else{
				$res=$this->rom_model->insert_indb('contact',$_POST);
				if($res>0){
					echo json_encode(array('status'=>'success','desc'=>'Contact Added.'));	

				}
				else{
					echo json_encode(array('status'=>'error','desc'=>'Invalid Contact.'));	

				}

			}
		}

		public function send_sms(){
			$data['group']=$this->rom_model->get_data_fromdb('group');
			$data['library']=$this->rom_model->get_data_fromdb('library');
			$this->load->view('send-sms',$data);
		}

		public function send_grsms_action(){
			$res=$this->rom_model->get_grsms($_POST);
			
			if(is_array($res) && !empty($res)){
				foreach($res as $val){
					echo "<span style='cursor:pointer' onclick=showdata('".$val['c_name']."','".$val['c_number']."')>".$val['c_name']."</span><br>";
				}
			}
			else{
				echo"Create Contact first <a href='".base_url('index.php/rom/add_contact')."'>Click here</a>";
			}



		
		}

		function send_sms_action(){
			//print_r($_POST);
			$res=$this->rom_model->send_sms_action($_POST);
			// print_r($res);
			if(is_array($res) && !empty($res)){
				foreach ($res as $value) {
					echo "<span style=\"cursor:pointer\" onclick=\"showsms('".$value['sms_msg']."')\">".$value['sms_msg']."</span><br>";
				}
			}
			else{
				echo"Create message first <a href='".base_url('index.php/rom/create_message')."'>Click here</a>";
			
			}

		}

		function send_message_action(){
			// print_r($_POST);
			$this->form_validation->set_rules('per_name','person name','trim|required|alpha');
			$this->form_validation->set_rules('per_mobile','mobile number','trim|required|exact_length[10]|numeric');
			$this->form_validation->set_rules('me_name','message','trim|required|alpha_numeric_spaces');

			if(!$this->form_validation->run()){
				echo json_encode(array('status'=>'error','desc'=>validation_errors()));	
			}
			else{
				$data=array('per_name'=>$_POST['per_name'],'per_mobile'=>$_POST['per_mobile'],'per_message'=>$_POST['me_name']);
				$res=$this->rom_model->insert_indb('sendsms',$data);
				print_r($res);
				if($res>0){
					echo json_encode(array('status'=>'success','desc'=>'Message send successfully.'));	

				}
				else{

				}
			}
		}

	}


?>