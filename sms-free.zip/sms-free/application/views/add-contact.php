<?php 
	$this->load->view('header');
 ?>
<div class="container-fluid">
	<div class="container">
		<div class="row">			
			<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
				<h2>Add <span>Contact Person</span></h2>
				<div class="nmessage_form">
					<form id="person_form">
						<div class="form-group">	
							<div class="input-group clearfix">
								
								<?php //print_r($group); ?>
								<select name="c_grid" id="c_grid" 	>
									<option value="">Please select</option>
									<?php 
									if(is_array($group)){
									foreach($group as $val){ ?>
									<option value="<?php echo$val['gr_id']; ?>"><?php echo$val['gr_name']; ?></option>
									<?php }} ?>
								</select>
							</div>
						</div>
						<div class="form-group">	
							<div class="input-group clearfix">
							  <input type="text" class="form-control" id="exampleInput" placeholder="Name" name="c_name">      
							</div>
							<div class="input-group clearfix">
							  <input type="text" class="form-control" id="exampleInput" placeholder="Mobile No." name="c_number">      
							</div>
							<div class="input-group">				      
							  <button type="button" class="btn btn-primary per_btn">Add Contact</button>		      
							</div>
						</div>
					</form>
					<div class="err_per"></div>
				</div>				
			</div>
			<div class="col-lg-offset-1 col-lg-7 col-md-7 col-sm-12 col-xs-12">
				<h2>Contact <span>Person</span></h2>
				<?php
					// print_r($contact);
					if(is_array($contact)){
						foreach($contact as $con){
				?>
				<ul class="list">
					<li><span><?php echo $con['c_name']; ?></span><span>+91 <?php echo $con['c_number']; ?></span></li>
				</ul>
				<?php
						}
					}
				?>
			</div>			
		</div>
	</div><br/>
</div>
<?php 
	$this->load->view('footer')
 ?>
