<link rel="icon" href="<?php echo base_url('images/favicon.png');?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/font-awesome.min.css');?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/flexy-menu.css');?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css');?>">
