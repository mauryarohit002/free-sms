<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>SMS FREE</title>
	<?php $this->load->view('head')?>
	<script type="text/javascript">
		var aurl="<?php echo base_url('index.php/rom/'); ?>";
	</script>	
</head>
<body>
	<header>
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right">
					<div class="pull-right">
						<?php
							if(!$this->session->userdata('email')):
						?>
						<ul class="login-menu login-top-padd">
							<li><a href="<?php echo base_url('index.php/rom/login') ?>"><i class="glyphicon glyphicon-user"></i> Login / Register</a></li>
						</ul>
						<?php
							endif;
						?>
						
						<?php
							if($this->session->userdata('email')):
						?>
						<ul class="login-menu login-top-padd">
							<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-user"></i> Welcome <?php echo $this->session->userdata('email');?> <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a href="<?php echo base_url('index.php/rom/change_pass') ?>">Change Password</a></li>
									<li><a href="<?php echo base_url('index.php/rom/logout') ?>">Logout</a></li>
								</ul>							
							</li>
							
						</ul>
						<?php
							endif;
						?>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
					<figure class="logo">
						<a href="<?php echo base_url('index.php/rom/index');?>"><img src="<?php echo base_url('assets/images/logo.png');?>" alt="SMS Free" class="img-responsive"></a>
					</figure>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<ul class="flexy-menu main-menu">
						<li <?php //active('index.php');?>><a href="<?php echo base_url('index.php/rom/index') ?>">Home</a></li>
						<li <?php //active('about-us.php');?>><a href="<?php echo base_url('index.php/rom/about_us') ?>">About Us</a></li>
						<li <?php //active('contact-us.php');?>><a href="<?php echo base_url('index.php/rom/contact_us') ?>">Contact Us</a></li>
					</ul>
				</div>
			</div>			
		</div>
	</header>
	<?php
		if($this->session->userdata('email')):
	?>
	<div class="menu-block">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<ul class="flexy-menu orange">						
						<li <?php //active('library.php');?>><a href="library.php">Library / Group</a></li>
						<li <?php //active('create-message.php');?>><a href="create-message.php">Create Message</a></li>
						<li <?php //active('add-contact.php');?>><a href="add-contact.php">Add Contact</a></li>
						<li <?php //active('send-sms.php');?>><a href="send-sms.php">Send SMS</a></li>
						<li <?php //active('group-sms.php');?>><a href="group-sms.php">Group SMS</a></li>
						<li <?php //active('sent-sms.php');?>><a href="sent-sms.php">Sent SMS</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<?php
		endif;
	?>