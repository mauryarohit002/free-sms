<?php
	
	class Rom_model extends CI_Model{
		public function __construct()	
		{	
			parent::__construct();

		}	
			
		function register_action($data){
			return $this->db->insert('login',$data);
			
		}

		function login_action($data){
			
			$res=$this->db->get_where('login',array('email'=>$data['email'],'pass'=>$data['pass']));
			
			if($res->num_rows()>0)return true;
		}


	}
?>