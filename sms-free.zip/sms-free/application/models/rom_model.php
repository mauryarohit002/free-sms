<?php
	
	class Rom_model extends CI_Model{
		public function __construct()	
		{	
			parent::__construct();

		}	
			
		function insert_indb($table,$data){
			return $this->db->insert($table,$data);
			
		}

		function login_action($data){
			
			$this->db->where(array('email'=>$data['email'],'pass'=>$data['pass']));
			$res=$this->db->get('login');
			
			if($res->num_rows()>0){
				return true;
			}
		}

		function change_password_action($rec){
			// print_r($rec);
			$this->db->where(array('email'=>$rec['email'],'pass'=>$rec['cpass']));
			$query=$this->db->get('login');
			if($query->num_rows()>0){
				$this->db->where(array('email'=>$rec['email'],'pass'=>$rec['cpass']));
				return$res=$this->db->update('login',array('pass'=>$rec['pass']));
			}


		}

		function get_data_fromdb($data){
			return $query=$this->db->get($data)->result_array();
			
		}

		
	}
?>