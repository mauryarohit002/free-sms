<?php
	
	class Rom_model extends CI_Model{
		public function __construct()	
		{	
			parent::__construct();

		}	
			
		function register_action($data){
			return $this->db->insert('login',$data);
			
		}

		function login_action($data){
			
			$this->db->where(array('email'=>$data['email'],'pass'=>$data['pass']));
			$res=$this->db->get('login');
			
			if($res->num_rows()>0){
				return true;
			}
		}

		function change_password_action($rec){
			// print_r($rec);
			$this->db->where(array('email'=>$rec['email'],'pass'=>$rec['cpass']));
			$query=$this->db->get('login');
			if($query->num_rows()>0){
				$this->db->where(array('email'=>$rec['email'],'pass'=>$rec['cpass']));
				return$res=$this->db->update('login',array('pass'=>$rec['pass']));
			}


		}

		function get_librarydata(){
			return $query=$this->db->get('library')->result_array();
			
		}

		function get_groupdata(){
			return$query=$this->db->get('group')->result_array();
			//print_r($query);
		}

		function add_library_indb($data){
			return $this->db->insert('library',$data);
		}

		function add_group_indb($data){
			return $this->db->insert('group',$data);

		}


	}
?>