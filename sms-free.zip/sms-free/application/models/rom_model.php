<?php
	
	class Rom_model extends CI_Model{
		public function __construct()	
		{	
			parent::__construct();

		}	
			
		function register_action($data){
			return $this->db->insert('login',$data);
			
		}


	}
?>