-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2018 at 12:40 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `demo-sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `person_contact`
--

CREATE TABLE IF NOT EXISTS `person_contact` (
`per_id` int(11) NOT NULL,
  `per_name` varchar(100) DEFAULT NULL,
  `per_mobile` bigint(20) DEFAULT NULL,
  `per_grid` varchar(100) DEFAULT NULL,
  `per_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `person_contact`
--

INSERT INTO `person_contact` (`per_id`, `per_name`, `per_mobile`, `per_grid`, `per_time`) VALUES
(21, 'Suraj', 9090808070, '18', '2017-12-28 15:11:44'),
(22, 'Sujay', 7890789090, '17', '2017-12-28 15:11:55'),
(23, 'Adnan', 7894561230, '19', '2018-01-16 06:03:20'),
(24, 'Avinash', 4567891230, '19', '2018-01-16 06:03:28'),
(25, 'Gaurav', 9619404202, '20', '2018-04-01 06:02:14'),
(26, 'Sachin', 9619404202, '20', '2018-04-01 06:02:22'),
(27, 'Aniket', 8965231470, '21', '2018-04-05 07:12:25'),
(28, 'Gaurav', 7896541230, '21', '2018-04-05 07:12:35'),
(29, 'GRP', 9898898990, '22', '2018-04-25 05:19:53'),
(30, 'Akshay', 8956895623, '23', '2018-05-11 04:15:13'),
(31, 'Akshay', 8956238956, '25', '2018-05-24 07:46:42'),
(32, 'Akki', 1234567890, '25', '2018-05-24 07:47:07'),
(33, 'Hanuman', 8965896520, '26', '2018-05-28 13:27:05'),
(34, 'The Amit', 8965785410, '26', '2018-05-28 13:27:14'),
(35, 'saurabh', 5689745120, '25', '2018-08-05 06:48:21'),
(36, 'abc', 9874563210, '25', '2018-10-13 13:43:43'),
(37, 'sudhir', 9773891468, '27', '2018-10-18 08:56:19');

-- --------------------------------------------------------

--
-- Table structure for table `sms_category`
--

CREATE TABLE IF NOT EXISTS `sms_category` (
`ca_id` int(11) NOT NULL,
  `ca_name` varchar(100) DEFAULT NULL,
  `ca_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `sms_category`
--

INSERT INTO `sms_category` (`ca_id`, `ca_name`, `ca_time`) VALUES
(21, 'Diwali', '2017-12-28 15:10:46'),
(22, 'New Year', '2017-12-28 15:11:21'),
(23, 'College Days', '2018-01-16 06:02:18'),
(24, 'April Month', '2018-04-01 06:01:29'),
(25, 'Maharashtra Day', '2018-04-05 07:11:08'),
(26, 'LIBNAME', '2018-04-25 05:19:16'),
(27, 'BirthDay', '2018-05-11 04:14:27'),
(28, 'Happy BirthDay', '2018-05-24 07:45:14'),
(29, 'Summer Lib', '2018-05-28 13:26:29'),
(30, 'FriendShip Day', '2018-08-05 06:47:40'),
(31, 'Node lib', '2018-10-13 13:42:01'),
(32, 'test', '2018-10-18 08:54:56');

-- --------------------------------------------------------

--
-- Table structure for table `sms_group`
--

CREATE TABLE IF NOT EXISTS `sms_group` (
`gr_id` int(11) NOT NULL,
  `gr_name` varchar(100) DEFAULT NULL,
  `gr_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `sms_group`
--

INSERT INTO `sms_group` (`gr_id`, `gr_name`, `gr_time`) VALUES
(17, 'Friends', '2017-12-28 15:10:53'),
(18, 'College', '2017-12-28 15:11:00'),
(19, 'Society Friends', '2018-01-16 06:02:30'),
(20, 'My PHP Group', '2018-04-01 06:01:17'),
(21, 'My School Friend', '2018-04-05 07:10:21'),
(22, 'GROUPNAME', '2018-04-25 05:19:24'),
(23, 'College Friends', '2018-05-11 04:14:34'),
(24, 'My Group', '2018-05-24 07:46:15'),
(25, 'My Friends', '2018-05-24 07:46:20'),
(26, 'PHP GROUP', '2018-05-28 13:26:37'),
(27, 'group test', '2018-10-18 08:55:10');

-- --------------------------------------------------------

--
-- Table structure for table `sms_login`
--

CREATE TABLE IF NOT EXISTS `sms_login` (
`log_id` int(11) NOT NULL,
  `log_name` varchar(100) DEFAULT NULL,
  `log_email` varchar(100) DEFAULT NULL,
  `log_mobile` bigint(20) DEFAULT NULL,
  `log_pass` varchar(100) DEFAULT NULL,
  `log_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `sms_login`
--

INSERT INTO `sms_login` (`log_id`, `log_name`, `log_email`, `log_mobile`, `log_pass`, `log_time`) VALUES
(22, 'keeran', 'keeran@gmail.com', 9619404202, '86c8425bb4cd54c772a247a51e67f33fa663becd', '2017-12-28 15:09:35'),
(23, 'rohit', 'rohit@gmail.com', 9860098600, '86c8425bb4cd54c772a247a51e67f33fa663becd', '2018-01-16 06:01:16'),
(24, 'amit', 'amit@gmail.com', 9619404202, '86c8425bb4cd54c772a247a51e67f33fa663becd', '2018-04-01 06:00:37'),
(25, 'tapas', 'tapas@gmail.co', 9619404202, '86c8425bb4cd54c772a247a51e67f33fa663becd', '2018-04-05 07:09:28'),
(26, 'test', 'test@test.com', 9809809800, '86c8425bb4cd54c772a247a51e67f33fa663becd', '2018-04-25 05:18:48'),
(27, 'Ajay', 'ajay@gmail.com', 9619404202, '86c8425bb4cd54c772a247a51e67f33fa663becd', '2018-05-11 04:14:10'),
(28, 'pinank', 'pinank@gmail.com', 9820098200, '86c8425bb4cd54c772a247a51e67f33fa663becd', '2018-05-24 07:43:54'),
(29, 'ashish', 'ashishrao@gmail.coom', 9619404202, '86c8425bb4cd54c772a247a51e67f33fa663becd', '2018-05-28 13:26:03'),
(30, 'sandeep', 'sandeep@gmail.com', 9619404200, '86c8425bb4cd54c772a247a51e67f33fa663becd', '2018-08-05 06:47:13'),
(31, 'rupesh', 'rupesh.indre@gmail.com', 7208538939, '86c8425bb4cd54c772a247a51e67f33fa663becd', '2018-10-13 13:41:13'),
(32, 'sudhir', 'sudhirsingh4116@gmail.com', 9773891468, 'cb7a0ba5194eb23443da07a65f18f79b87edb595', '2018-10-18 08:54:02');

-- --------------------------------------------------------

--
-- Table structure for table `sms_message`
--

CREATE TABLE IF NOT EXISTS `sms_message` (
`sms_id` int(11) NOT NULL,
  `sms_msg` varchar(100) DEFAULT NULL,
  `sms_caid` int(11) DEFAULT NULL,
  `sms_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `sms_message`
--

INSERT INTO `sms_message` (`sms_id`, `sms_msg`, `sms_caid`, `sms_time`) VALUES
(24, 'Happy Diwali', 21, '2017-12-28 15:11:12'),
(25, 'Happy new Year', 22, '2017-12-28 15:11:31'),
(26, 'Some Test Messages', 23, '2018-01-16 06:03:03'),
(27, 'Dummy Messages', 23, '2018-01-16 06:03:09'),
(28, 'HEllo April', 24, '2018-04-01 06:01:48'),
(29, 'April MOnth 2', 24, '2018-04-01 06:01:59'),
(30, 'Wish u happy maharashtra daya', 25, '2018-04-05 07:11:35'),
(31, 'Happy Maharashtra Day', 25, '2018-04-05 07:11:46'),
(32, 'LIB MESSAGE', 26, '2018-04-25 05:19:35'),
(33, 'Wish You Happy Bday', 27, '2018-05-11 04:14:56'),
(34, 'Wish u happy Birthday', 28, '2018-05-24 07:45:57'),
(35, 'Happy Bday', 28, '2018-05-24 07:46:02'),
(36, 'Its Too HOt', 29, '2018-05-28 13:26:52'),
(37, 'Hello', 30, '2018-08-05 06:48:02'),
(38, 'Hello1', 30, '2018-08-05 06:48:06'),
(39, 'Test hiii', 31, '2018-10-13 13:42:49'),
(40, 'hello ', 32, '2018-10-18 08:55:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `person_contact`
--
ALTER TABLE `person_contact`
 ADD PRIMARY KEY (`per_id`);

--
-- Indexes for table `sms_category`
--
ALTER TABLE `sms_category`
 ADD PRIMARY KEY (`ca_id`);

--
-- Indexes for table `sms_group`
--
ALTER TABLE `sms_group`
 ADD PRIMARY KEY (`gr_id`);

--
-- Indexes for table `sms_login`
--
ALTER TABLE `sms_login`
 ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `sms_message`
--
ALTER TABLE `sms_message`
 ADD PRIMARY KEY (`sms_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `person_contact`
--
ALTER TABLE `person_contact`
MODIFY `per_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `sms_category`
--
ALTER TABLE `sms_category`
MODIFY `ca_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `sms_group`
--
ALTER TABLE `sms_group`
MODIFY `gr_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `sms_login`
--
ALTER TABLE `sms_login`
MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `sms_message`
--
ALTER TABLE `sms_message`
MODIFY `sms_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
