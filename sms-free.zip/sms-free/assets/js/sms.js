$(function(){
	$('.reg_btn').click(function(){
		// alert(aurl);
		var rec=$('#register_form').serialize();
		// alert(rec);
		$.ajax({
			type:"post",
			url:aurl+"register_action",
			data:rec,
			success:function(response){
				var data=JSON.parse(response);
				if(data.status="success"){
					$('.err_reg').html(data.desc);
				}
				else{
					$('.err_reg').html(data.desc);
					
				}
			}
		})

	})

	$('.log_btn').click(function(){
		var rec=$('#login_form').serialize();
		// alert(rec);
		$.ajax({
			type:'post',
			url:aurl+"login_action",
			data:rec,
			success:function(res){
				var data = JSON.parse(res);
				if(data.status='success'){
					// $('.err_log').html(data.desc);
					window.location.href=aurl+"index";
				}
				else{
					$('.err_log').html(data.desc);
					
				}
			}
		})
	})


	$('.change_pass').click(function(){
		var rec= $('#changepass_form').serialize();
		// alert(rec);
		$.ajax({
					type:'POST',
					data:rec,
					url:aurl+"change_password_action",
					
					success:function(response){
						var val=JSON.parse(response);
						// alert(val.status);
						if(val.status="success"){
							$('.err_changepass').html(val.desc);
							$('#changepass_form')[0].reset();
						}
						else{
							$('.err_changepass').html(val.desc);
						}
					}
		})
	})


	/////  Add Category or Group ////////////
	
	$(".group_form").hide();
	$(".radio_cagr").change(function(){
		//alert (1);
		var ans = $(this).is(":checked");
		//alert (ans);
		
		var record = $(this).val();
		//alert(record);
		
		if(record==1){
			$(".group_form").slideUp();
			$(".category_form").slideDown();
		}
		else{
			$(".group_form").slideDown();
			$(".category_form").slideUp();
		}
	});

	$('.cat_btn').click(function(){
		// alert(aurl);
		var rec=$('#category_form').serialize();
		$.ajax({
			type:'POST',
			data:rec,
			url:aurl+"add_library",
			success:function(res){
				var res=JSON.parse(res);
				if(res.status="success"){
					$('.err_cat').html(res.desc);
				}
				else{
					$('.err_cat').html(res.desc);
				}
			}
		})

	})

	$('.gr_btn').click(function(){
		// alert(aurl);
		var rec=$('#group_form').serialize();
		$.ajax({
			type:'POST',
			data:rec,
			url:aurl+"add_group",
			success:function(res){
				var res=JSON.parse(res);
				if(res.status="success"){
					$('.err_group').html(res.desc);
				}
				else{
					$('.err_group').html(res.desc);
				}
			}
		})

	})

	$('.msg_btn').click(function(){
		// alert(aurl);
		var rec=$('#nmessage_form').serialize();
		$.ajax({
			type:'POST',
			data:rec,
			url:aurl+"add_message",
			success:function(resp){
				
				var res=JSON.parse(resp);
				 
				if(res.status="success"){
					$('.err_nmessage').html(res.desc);
				}
				else{
					$('.err_nmessage').html(res.desc);
				}
			}
		})

	})

	$('.per_btn').click(function(){
		var rec=$('#person_form').serialize();
		$.ajax({
			type:'POST',
			data:rec,
			url:aurl+"add_contactdb",
			success:function(res){
				var res=JSON.parse(res);
				if(res.status="success"){
					$('.err_per').html(res.desc);
				}
				else{
					$('.err_per').html(res.desc);
				}
			}
		})

	})

})