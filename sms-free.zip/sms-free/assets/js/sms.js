$(function(){
	$('.reg_btn').click(function(){
		// alert(aurl);
		var rec=$('#register_form').serialize();
		// alert(rec);
		$.ajax({
			type:"post",
			url:aurl+"register_action",
			data:rec,
			success:function(response){
				var data=JSON.parse(response);
				if(data.status="success"){
					$('.err_reg').html(data.desc);
				}
				else{
					$('.err_reg').html(data.desc);
					
				}
			}
		})

	})
})