<?php 
	require_once 'afterlogin.php';
	require_once 'incs/header.php';
?>
<div class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h2>Sent <span>SMS</span></h2>
				<p><a href="#">Single SMS</a> / <a href="#">Group SMS</a> / <a href="#"></a></p>
			</div>
		</div>
	</div><br/>
</div>
<?php 
	require_once 'incs/footer.php';
?>